# Databricks Deployment Steps

## Step-by-Step Deployment Guide

### 1. Pre-Deployment Checklist
- [ ] Databricks workspace access
- [ ] Unity Catalog enabled
- [ ] Volume permissions: `/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp`
- [ ] Cluster creation permissions
- [ ] Notebook import permissions

### 2. Upload Source Files

#### Option A: Using Databricks CLI (Recommended)
```bash
# Install Databricks CLI if not already installed
pip install databricks-cli

# Configure authentication
databricks configure --token

# Upload source files
databricks fs cp src/ dbfs:/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/src/ --recursive
```

#### Option B: Using Databricks UI
1. Navigate to your Databricks workspace
2. Go to **Data** → **Browse** → **Volumes**
3. Navigate to: `usdev_dataengineering` → `eds_us_lake_cdp` → `volume_entcdp`
4. Create folder: `src`
5. Upload all files from the `src/` directory

### 3. Import Notebooks

#### Using Databricks UI:
1. Go to **Workspace** in your Databricks workspace
2. Navigate to your user folder or create a new folder: `informatica_converter`
3. Click **Import** and select the notebook files:
   - `notebooks/01_Setup.py`
   - `notebooks/02_Main_Execution.py`
   - `notebooks/03_Monitoring_Dashboard.py`

### 4. Create Cluster

#### Recommended Cluster Configuration:
```json
{
  "cluster_name": "informatica-migration-cluster",
  "spark_version": "13.3.x-scala2.12",
  "node_type_id": "i3.xlarge",
  "driver_node_type_id": "i3.xlarge",
  "num_workers": 2,
  "autoscale": {
    "min_workers": 1,
    "max_workers": 8
  }
}
```

#### Steps:
1. Go to **Compute** → **Create Cluster**
2. Use the configuration above or adjust based on your needs
3. Start the cluster

### 5. Run Setup Notebook

1. Open `01_Setup.py` notebook
2. Attach it to your cluster
3. Run all cells sequentially
4. Verify all steps complete successfully:
   - ✅ Libraries installed
   - ✅ Volume access confirmed
   - ✅ Directories created
   - ✅ Metadata tables created
   - ✅ Modules imported successfully

### 6. Upload XML Workflow Files

Upload your Informatica XML files to:
`/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/xml_workflows/`

#### Using Databricks UI:
1. Navigate to the volume path above
2. Upload your `.xml` files

#### Using Databricks CLI:
```bash
databricks fs cp your_xml_files/ dbfs:/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/xml_workflows/ --recursive
```

### 7. Execute Conversion

1. Open `02_Main_Execution.py` notebook
2. Attach it to your cluster
3. Run all cells to start the conversion process
4. Monitor the progress and results

### 8. Monitor and Validate

1. Open `03_Monitoring_Dashboard.py` notebook
2. Review conversion statistics and results
3. Check generated notebooks in the `generated_notebooks` directory

## Post-Deployment Validation

### Test Conversion with Sample File
```python
# In a new notebook cell
import sys
sys.path.append('/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/src')

from informatica_bdm_parser import InformaticaBDMParser
from databricks_generator import DatabricksNotebookGenerator

# Test with a single XML file
parser = InformaticaBDMParser()
generator = DatabricksNotebookGenerator()

# Replace with your actual XML file path
xml_file = "/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/xml_workflows/sample_workflow.xml"

try:
    workflow = parser.parse_xml_file(xml_file)
    notebook_code = generator.generate_notebook(workflow)
    print("✅ Test conversion successful!")
    print(f"Generated notebook length: {len(notebook_code)} characters")
except Exception as e:
    print(f"❌ Test conversion failed: {e}")
```

## Troubleshooting Common Issues

### Issue 1: Volume Access Denied
```
Error: java.nio.file.AccessDeniedException
```
**Solution:**
1. Check your permissions on the volume
2. Contact your Databricks admin to grant access
3. Verify the volume path is correct

### Issue 2: Module Import Errors
```
ModuleNotFoundError: No module named 'informatica_bdm_parser'
```
**Solution:**
1. Verify files are uploaded to the correct path
2. Check the `sys.path.append()` statement
3. Restart the cluster if needed

### Issue 3: Table Creation Errors
```
Error creating metadata tables
```
**Solution:**
1. Check Unity Catalog permissions
2. Verify catalog and schema names
3. Ensure you have CREATE TABLE permissions

## Performance Optimization

### For Large Workloads (>500 workflows):
1. **Increase cluster size**: 8-16 workers
2. **Use larger instance types**: `i3.2xlarge` or `i3.4xlarge`
3. **Enable autoscaling**: Set max workers to 20+
4. **Process in batches**: 50-100 workflows at a time

### For Better Performance:
```python
# In databricks_config.py, update SPARK_CONFIG:
SPARK_CONFIG = {
    "spark.databricks.delta.optimizeWrite.enabled": "true",
    "spark.databricks.delta.autoCompact.enabled": "true",
    "spark.sql.adaptive.enabled": "true",
    "spark.sql.adaptive.coalescePartitions.enabled": "true",
    "spark.sql.adaptive.skewJoin.enabled": "true",
    "spark.databricks.io.cache.enabled": "true"
}
```

## Security Considerations

1. **Access Control**: Limit notebook access to authorized users
2. **Data Protection**: Ensure XML files don't contain sensitive data
3. **Audit Logging**: Monitor conversion activities through the tracking tables

## Maintenance Tasks

### Weekly:
- Review conversion success rates
- Check for failed conversions and resolve issues
- Monitor cluster utilization

### Monthly:
- Clean up old log files
- Optimize Delta tables
- Review and update cluster configurations

## Getting Help

If you encounter issues:
1. Check the monitoring dashboard for error patterns
2. Review the troubleshooting section above
3. Check Databricks documentation
4. Contact your data engineering team

---

**Next Steps:** After successful deployment, proceed to convert your workflows and monitor the results using the provided notebooks.