#!/usr/bin/env python3
"""
Workflow Analyzer
Analyzes Informatica BDM workflows to understand patterns and complexity
"""

from informatica_bdm_parser import InformaticaBDMParser, WorkflowDefinition
from typing import Dict, List, Any, Set
import json
from pathlib import Path
from collections import defaultdict, Counter

# Try to import pandas, but make it optional
try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False

class WorkflowAnalyzer:
    """Analyzes workflows to identify patterns and generate migration statistics"""
    
    def __init__(self):
        self.parser = InformaticaBDMParser()
        self.analysis_results = {
            'total_workflows': 0,
            'transformation_patterns': defaultdict(int),
            'parameter_patterns': defaultdict(int),
            'complexity_scores': [],
            'cluster_configurations': defaultdict(int),
            'workflow_dependencies': [],
            'common_expressions': defaultdict(int),
            'data_sources': set(),
            'data_targets': set()
        }
    
    def analyze_workflow_batch(self, xml_files: List[str]) -> Dict[str, Any]:
        """Analyze a batch of workflow XML files"""
        print(f"Analyzing {len(xml_files)} workflow files...")
        
        successful_parses = 0
        failed_parses = 0
        
        for xml_file in xml_files:
            try:
                workflow = self.parser.parse_xml_file(xml_file)
                self._analyze_single_workflow(workflow, xml_file)
                successful_parses += 1
                
                if successful_parses % 100 == 0:
                    print(f"Processed {successful_parses} workflows...")
                    
            except Exception as e:
                failed_parses += 1
                print(f"Failed to parse {xml_file}: {e}")
        
        self.analysis_results['successful_parses'] = successful_parses
        self.analysis_results['failed_parses'] = failed_parses
        self.analysis_results['total_workflows'] = successful_parses
        
        return self._generate_analysis_report()
    
    def _analyze_single_workflow(self, workflow: WorkflowDefinition, file_path: str):
        """Analyze a single workflow and update statistics"""
        
        # Basic workflow info
        workflow_info = {
            'name': workflow.name,
            'file_path': file_path,
            'parameter_count': len(workflow.parameters),
            'mapping_task_count': len(workflow.mapping_tasks),
            'sequence_flow_count': len(workflow.sequence_flows)
        }
        
        # Analyze parameters
        for param in workflow.parameters:
            self.analysis_results['parameter_patterns'][param.name] += 1
        
        # Analyze cluster configuration
        for key, value in workflow.cluster_config.items():
            if 'databricks' in key.lower():
                clean_key = key.split('.')[-1]
                self.analysis_results['cluster_configurations'][f"{clean_key}:{value}"] += 1
        
        # Analyze mapping tasks
        total_transformations = 0
        for mapping_task in workflow.mapping_tasks:
            total_transformations += len(mapping_task.transformations)
            
            # Count transformation types
            for trans in mapping_task.transformations:
                self.analysis_results['transformation_patterns'][trans.type] += 1
                
                # Analyze expressions
                if hasattr(trans, 'expressions') and trans.expressions:
                    for field, expr in trans.expressions.items():
                        # Extract common expression patterns
                        self._extract_expression_patterns(expr)
            
            # Track data sources and targets
            for source in mapping_task.sources:
                self.analysis_results['data_sources'].add(source.name)
            
            for target in mapping_task.targets:
                self.analysis_results['data_targets'].add(target.name)
        
        # Calculate complexity score
        complexity_score = self._calculate_complexity_score(workflow, total_transformations)
        self.analysis_results['complexity_scores'].append({
            'workflow_name': workflow.name,
            'score': complexity_score,
            'transformations': total_transformations,
            'parameters': len(workflow.parameters),
            'mapping_tasks': len(workflow.mapping_tasks)
        })
    
    def _extract_expression_patterns(self, expression: str):
        """Extract common patterns from expressions"""
        import re
        
        # Common function patterns
        functions = re.findall(r'\b([A-Z_]+)\s*\(', expression)
        for func in functions:
            self.analysis_results['common_expressions'][f"FUNCTION:{func}"] += 1
        
        # Common operators
        operators = re.findall(r'(\|\||&&|==|!=|<=|>=|<|>)', expression)
        for op in operators:
            self.analysis_results['common_expressions'][f"OPERATOR:{op}"] += 1
    
    def _calculate_complexity_score(self, workflow: WorkflowDefinition, total_transformations: int) -> int:
        """Calculate workflow complexity score"""
        score = 0
        
        # Base score from transformation count
        score += total_transformations * 2
        
        # Parameter complexity
        score += len(workflow.parameters)
        
        # Mapping task complexity
        score += len(workflow.mapping_tasks) * 3
        
        # Sequence flow complexity (dependencies)
        score += len(workflow.sequence_flows)
        
        # Bonus for complex transformations
        for mapping_task in workflow.mapping_tasks:
            for trans in mapping_task.transformations:
                if trans.type in ['joiner', 'lookup', 'router']:
                    score += 5
                elif trans.type == 'expression':
                    score += len(trans.expressions) if hasattr(trans, 'expressions') else 1
        
        return score
    
    def _generate_analysis_report(self) -> Dict[str, Any]:
        """Generate comprehensive analysis report"""
        
        # Convert sets to lists for JSON serialization
        self.analysis_results['data_sources'] = list(self.analysis_results['data_sources'])
        self.analysis_results['data_targets'] = list(self.analysis_results['data_targets'])
        
        # Calculate statistics
        complexity_scores = [item['score'] for item in self.analysis_results['complexity_scores']]
        
        report = {
            'summary': {
                'total_workflows_analyzed': self.analysis_results['total_workflows'],
                'successful_parses': self.analysis_results['successful_parses'],
                'failed_parses': self.analysis_results['failed_parses'],
                'success_rate': f"{(self.analysis_results['successful_parses'] / (self.analysis_results['successful_parses'] + self.analysis_results['failed_parses']) * 100):.1f}%" if self.analysis_results['successful_parses'] + self.analysis_results['failed_parses'] > 0 else "0%"
            },
            'transformation_analysis': {
                'total_transformations': sum(self.analysis_results['transformation_patterns'].values()),
                'transformation_types': dict(self.analysis_results['transformation_patterns']),
                'most_common_transformations': dict(Counter(self.analysis_results['transformation_patterns']).most_common(10))
            },
            'parameter_analysis': {
                'total_unique_parameters': len(self.analysis_results['parameter_patterns']),
                'most_common_parameters': dict(Counter(self.analysis_results['parameter_patterns']).most_common(10))
            },
            'complexity_analysis': {
                'average_complexity': sum(complexity_scores) / len(complexity_scores) if complexity_scores else 0,
                'max_complexity': max(complexity_scores) if complexity_scores else 0,
                'min_complexity': min(complexity_scores) if complexity_scores else 0,
                'high_complexity_workflows': [
                    item for item in self.analysis_results['complexity_scores'] 
                    if complexity_scores and item['score'] > (sum(complexity_scores) / len(complexity_scores) * 1.5)
                ]
            },
            'data_analysis': {
                'unique_data_sources': len(self.analysis_results['data_sources']),
                'unique_data_targets': len(self.analysis_results['data_targets']),
                'data_sources': self.analysis_results['data_sources'][:20],  # Top 20
                'data_targets': self.analysis_results['data_targets'][:20]   # Top 20
            },
            'cluster_analysis': {
                'cluster_configurations': dict(Counter(self.analysis_results['cluster_configurations']).most_common(10))
            },
            'expression_analysis': {
                'common_expressions': dict(Counter(self.analysis_results['common_expressions']).most_common(15))
            }
        }
        
        return report
    
    def generate_migration_recommendations(self, analysis_report: Dict[str, Any]) -> Dict[str, Any]:
        """Generate migration recommendations based on analysis"""
        
        recommendations = {
            'priority_workflows': [],
            'transformation_mapping': {},
            'optimization_opportunities': [],
            'risk_assessment': {},
            'resource_requirements': {}
        }
        
        # Priority workflows (start with simple ones)
        complexity_scores = analysis_report['complexity_analysis']
        avg_complexity = complexity_scores['average_complexity']
        
        simple_workflows = [
            item for item in self.analysis_results['complexity_scores']
            if item['score'] < avg_complexity * 0.7
        ]
        
        recommendations['priority_workflows'] = {
            'phase_1_simple': simple_workflows[:50],  # First 50 simple workflows
            'phase_2_medium': [
                item for item in self.analysis_results['complexity_scores']
                if avg_complexity * 0.7 <= item['score'] <= avg_complexity * 1.3
            ][:100],
            'phase_3_complex': complexity_scores['high_complexity_workflows']
        }
        
        # Transformation mapping recommendations
        transformation_types = analysis_report['transformation_analysis']['transformation_types']
        
        for trans_type, count in transformation_types.items():
            if trans_type == 'expression':
                recommendations['transformation_mapping'][trans_type] = {
                    'spark_equivalent': 'DataFrame.withColumn() + expr()',
                    'complexity': 'Medium',
                    'automation_level': '90%',
                    'manual_review_needed': count > 1000
                }
            elif trans_type == 'joiner':
                recommendations['transformation_mapping'][trans_type] = {
                    'spark_equivalent': 'DataFrame.join()',
                    'complexity': 'Low',
                    'automation_level': '95%',
                    'manual_review_needed': False
                }
            elif trans_type == 'lookup':
                recommendations['transformation_mapping'][trans_type] = {
                    'spark_equivalent': 'broadcast(DataFrame).join()',
                    'complexity': 'Medium',
                    'automation_level': '85%',
                    'manual_review_needed': count > 500
                }
        
        # Resource requirements
        total_workflows = analysis_report['summary']['total_workflows_analyzed']
        
        recommendations['resource_requirements'] = {
            'estimated_conversion_time': {
                'simple_workflows': f"{len(recommendations['priority_workflows']['phase_1_simple']) * 0.5} days",
                'medium_workflows': f"{len(recommendations['priority_workflows']['phase_2_medium']) * 1.5} days",
                'complex_workflows': f"{len(recommendations['priority_workflows']['phase_3_complex']) * 3} days"
            },
            'team_size_recommendation': max(3, min(10, total_workflows // 500)),
            'automation_coverage': f"{(sum(transformation_types.values()) * 0.85 / sum(transformation_types.values()) * 100):.1f}%"
        }
        
        return recommendations
    
    def save_analysis_results(self, analysis_report: Dict[str, Any], output_dir: str = "analysis_results"):
        """Save analysis results to files"""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # Save main analysis report
        with open(output_path / "workflow_analysis_report.json", 'w') as f:
            json.dump(analysis_report, f, indent=2, default=str)
        
        # Save complexity scores as CSV if pandas is available
        if self.analysis_results['complexity_scores'] and HAS_PANDAS:
            df_complexity = pd.DataFrame(self.analysis_results['complexity_scores'])
            df_complexity.to_csv(output_path / "workflow_complexity_scores.csv", index=False)
        
        # Generate migration recommendations
        recommendations = self.generate_migration_recommendations(analysis_report)
        with open(output_path / "migration_recommendations.json", 'w') as f:
            json.dump(recommendations, f, indent=2, default=str)
        
        print(f"Analysis results saved to: {output_path}")
        return output_path

def main():
    """Test the analyzer with sample files"""
    analyzer = WorkflowAnalyzer()
    
    # Find all XML files in current directory
    xml_files = list(Path('.').glob('*.xml'))
    
    if not xml_files:
        print("No XML files found in current directory")
        return
    
    print(f"Found {len(xml_files)} XML files")
    
    # Analyze workflows
    analysis_report = analyzer.analyze_workflow_batch([str(f) for f in xml_files])
    
    # Print summary
    print("\n" + "="*60)
    print("WORKFLOW ANALYSIS SUMMARY")
    print("="*60)
    
    print(f"Total workflows analyzed: {analysis_report['summary']['total_workflows_analyzed']}")
    print(f"Success rate: {analysis_report['summary']['success_rate']}")
    print(f"Total transformations: {analysis_report['transformation_analysis']['total_transformations']}")
    print(f"Average complexity score: {analysis_report['complexity_analysis']['average_complexity']:.1f}")
    
    print("\nMost common transformations:")
    for trans_type, count in analysis_report['transformation_analysis']['most_common_transformations'].items():
        print(f"  - {trans_type}: {count}")
    
    print("\nMost common parameters:")
    for param, count in analysis_report['parameter_analysis']['most_common_parameters'].items():
        print(f"  - {param}: {count}")
    
    # Save results
    output_dir = analyzer.save_analysis_results(analysis_report)
    print(f"\n✅ Analysis complete! Results saved to: {output_dir}")

if __name__ == "__main__":
    main()