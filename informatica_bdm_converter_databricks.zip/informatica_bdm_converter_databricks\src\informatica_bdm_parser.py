#!/usr/bin/env python3
"""
Informatica BDM XML Parser
Parses Informatica Big Data Management workflow XML files
"""

import xml.etree.ElementTree as ET
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from pathlib import Path
import re

@dataclass
class Parameter:
    """Represents a workflow parameter"""
    name: str
    default_value: str
    description: str = ""
    data_type: str = "string"

@dataclass
class Transformation:
    """Represents a transformation in the workflow"""
    name: str
    type: str
    properties: Dict[str, Any] = field(default_factory=dict)
    expressions: Dict[str, str] = field(default_factory=dict)
    input_ports: List[str] = field(default_factory=list)
    output_ports: List[str] = field(default_factory=list)

@dataclass
class MappingTask:
    """Represents a mapping task containing transformations"""
    name: str
    transformations: List[Transformation] = field(default_factory=list)
    sources: List[Transformation] = field(default_factory=list)
    targets: List[Transformation] = field(default_factory=list)
    connections: List[Dict[str, str]] = field(default_factory=list)

@dataclass
class SequenceFlow:
    """Represents workflow sequence flow"""
    source: str
    target: str
    condition: str = ""

@dataclass
class WorkflowDefinition:
    """Complete workflow definition"""
    id: str
    name: str
    parameters: List[Parameter] = field(default_factory=list)
    mapping_tasks: List[MappingTask] = field(default_factory=list)
    sequence_flows: List[SequenceFlow] = field(default_factory=list)
    cluster_config: Dict[str, str] = field(default_factory=dict)

class InformaticaBDMParser:
    """Parser for Informatica BDM XML workflow files"""
    
    def __init__(self):
        self.namespaces = {
            'bpmn': 'http://www.omg.org/spec/BPMN/20100524/MODEL',
            'informatica': 'http://www.informatica.com/bpmn',
            'xsi': 'http://www.w3.org/2001/XMLSchema-instance'
        }
    
    def parse_xml_file(self, file_path: str) -> WorkflowDefinition:
        """Parse an Informatica BDM XML file"""
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            # Update namespaces from the actual XML
            self._update_namespaces(root)
            
            # Extract workflow information
            workflow = self._extract_workflow_definition(root, file_path)
            
            return workflow
            
        except ET.ParseError as e:
            raise ValueError(f"Invalid XML format in {file_path}: {e}")
        except Exception as e:
            raise RuntimeError(f"Error parsing {file_path}: {e}")
    
    def _update_namespaces(self, root):
        """Update namespaces from XML root element"""
        for prefix, uri in root.attrib.items():
            if prefix.startswith('xmlns:'):
                namespace_prefix = prefix[6:]  # Remove 'xmlns:'
                self.namespaces[namespace_prefix] = uri
            elif prefix == 'xmlns':
                self.namespaces['default'] = uri
    
    def _extract_workflow_definition(self, root, file_path: str) -> WorkflowDefinition:
        """Extract workflow definition from XML root"""
        
        # Get workflow ID and name
        workflow_id = root.get('id', Path(file_path).stem)
        workflow_name = root.get('name', Path(file_path).stem)
        
        # Find process element
        process_elem = self._find_element(root, './/bpmn:process')
        if process_elem is not None:
            workflow_name = process_elem.get('name', workflow_name)
            workflow_id = process_elem.get('id', workflow_id)
        
        workflow = WorkflowDefinition(
            id=workflow_id,
            name=workflow_name
        )
        
        # Extract parameters
        workflow.parameters = self._extract_parameters(root)
        
        # Extract cluster configuration
        workflow.cluster_config = self._extract_cluster_config(root)
        
        # Extract mapping tasks
        workflow.mapping_tasks = self._extract_mapping_tasks(root)
        
        # Extract sequence flows
        workflow.sequence_flows = self._extract_sequence_flows(root)
        
        return workflow
    
    def _extract_parameters(self, root) -> List[Parameter]:
        """Extract workflow parameters"""
        parameters = []
        
        # Look for parameter definitions in various locations
        param_elements = self._find_elements(root, './/bpmn:property') + \
                        self._find_elements(root, './/informatica:parameter') + \
                        self._find_elements(root, './/parameter')
        
        for param_elem in param_elements:
            name = param_elem.get('name', '')
            value = param_elem.get('value', param_elem.get('defaultValue', ''))
            description = param_elem.get('description', '')
            data_type = param_elem.get('type', 'string')
            
            if name:
                parameters.append(Parameter(
                    name=name,
                    default_value=value,
                    description=description,
                    data_type=data_type
                ))
        
        return parameters
    
    def _extract_cluster_config(self, root) -> Dict[str, str]:
        """Extract cluster configuration"""
        config = {}
        
        # Look for cluster configuration elements
        config_elements = self._find_elements(root, './/informatica:clusterConfig') + \
                         self._find_elements(root, './/clusterConfig') + \
                         self._find_elements(root, './/configuration')
        
        for config_elem in config_elements:
            for child in config_elem:
                key = child.get('name', child.tag)
                value = child.get('value', child.text or '')
                if key and value:
                    config[key] = value
        
        return config
    
    def _extract_mapping_tasks(self, root) -> List[MappingTask]:
        """Extract mapping tasks from workflow"""
        mapping_tasks = []
        
        # Look for mapping task elements
        task_elements = self._find_elements(root, './/bpmn:task') + \
                       self._find_elements(root, './/informatica:mappingTask') + \
                       self._find_elements(root, './/mappingTask')
        
        for task_elem in task_elements:
            task_name = task_elem.get('name', f"mapping_task_{len(mapping_tasks)}")
            
            mapping_task = MappingTask(name=task_name)
            
            # Extract transformations
            mapping_task.transformations = self._extract_transformations(task_elem)
            
            # Separate sources and targets
            for trans in mapping_task.transformations:
                if trans.type.lower() in ['source', 'sourcequalifier']:
                    mapping_task.sources.append(trans)
                elif trans.type.lower() in ['target', 'targetdefinition']:
                    mapping_task.targets.append(trans)
            
            # Extract connections
            mapping_task.connections = self._extract_connections(task_elem)
            
            mapping_tasks.append(mapping_task)
        
        return mapping_tasks
    
    def _extract_transformations(self, parent_elem) -> List[Transformation]:
        """Extract transformations from a parent element"""
        transformations = []
        
        # Look for transformation elements
        trans_elements = self._find_elements(parent_elem, './/transformation') + \
                        self._find_elements(parent_elem, './/informatica:transformation') + \
                        self._find_elements(parent_elem, './/bpmn:serviceTask')
        
        for trans_elem in trans_elements:
            trans_name = trans_elem.get('name', f"transformation_{len(transformations)}")
            trans_type = trans_elem.get('type', trans_elem.get('transformationType', 'unknown'))
            
            transformation = Transformation(
                name=trans_name,
                type=trans_type.lower()
            )
            
            # Extract properties
            transformation.properties = self._extract_transformation_properties(trans_elem)
            
            # Extract expressions
            transformation.expressions = self._extract_expressions(trans_elem)
            
            # Extract ports
            transformation.input_ports = self._extract_ports(trans_elem, 'input')
            transformation.output_ports = self._extract_ports(trans_elem, 'output')
            
            transformations.append(transformation)
        
        return transformations
    
    def _extract_transformation_properties(self, trans_elem) -> Dict[str, Any]:
        """Extract transformation properties"""
        properties = {}
        
        # Get all attributes
        properties.update(trans_elem.attrib)
        
        # Look for property elements
        prop_elements = self._find_elements(trans_elem, './/property') + \
                       self._find_elements(trans_elem, './/informatica:property')
        
        for prop_elem in prop_elements:
            name = prop_elem.get('name', '')
            value = prop_elem.get('value', prop_elem.text or '')
            if name:
                properties[name] = value
        
        return properties
    
    def _extract_expressions(self, trans_elem) -> Dict[str, str]:
        """Extract expressions from transformation"""
        expressions = {}
        
        # Look for expression elements
        expr_elements = self._find_elements(trans_elem, './/expression') + \
                       self._find_elements(trans_elem, './/informatica:expression') + \
                       self._find_elements(trans_elem, './/field')
        
        for expr_elem in expr_elements:
            field_name = expr_elem.get('name', expr_elem.get('fieldName', ''))
            expression = expr_elem.get('expression', expr_elem.text or '')
            
            if field_name and expression:
                expressions[field_name] = expression
        
        return expressions
    
    def _extract_ports(self, trans_elem, port_type: str) -> List[str]:
        """Extract input/output ports"""
        ports = []
        
        port_elements = self._find_elements(trans_elem, f'.//{port_type}Port') + \
                       self._find_elements(trans_elem, f'.//informatica:{port_type}Port')
        
        for port_elem in port_elements:
            port_name = port_elem.get('name', '')
            if port_name:
                ports.append(port_name)
        
        return ports
    
    def _extract_connections(self, parent_elem) -> List[Dict[str, str]]:
        """Extract connections between transformations"""
        connections = []
        
        conn_elements = self._find_elements(parent_elem, './/connection') + \
                       self._find_elements(parent_elem, './/informatica:connection') + \
                       self._find_elements(parent_elem, './/bpmn:sequenceFlow')
        
        for conn_elem in conn_elements:
            connection = {
                'source': conn_elem.get('sourceRef', conn_elem.get('from', '')),
                'target': conn_elem.get('targetRef', conn_elem.get('to', '')),
                'source_port': conn_elem.get('sourcePort', ''),
                'target_port': conn_elem.get('targetPort', '')
            }
            
            if connection['source'] and connection['target']:
                connections.append(connection)
        
        return connections
    
    def _extract_sequence_flows(self, root) -> List[SequenceFlow]:
        """Extract sequence flows"""
        sequence_flows = []
        
        flow_elements = self._find_elements(root, './/bpmn:sequenceFlow') + \
                       self._find_elements(root, './/sequenceFlow')
        
        for flow_elem in flow_elements:
            source = flow_elem.get('sourceRef', '')
            target = flow_elem.get('targetRef', '')
            condition = flow_elem.get('condition', '')
            
            if source and target:
                sequence_flows.append(SequenceFlow(
                    source=source,
                    target=target,
                    condition=condition
                ))
        
        return sequence_flows
    
    def _find_element(self, parent, xpath: str):
        """Find single element with namespace support"""
        try:
            return parent.find(xpath, self.namespaces)
        except:
            # Fallback without namespaces
            simple_xpath = re.sub(r'\w+:', '', xpath)
            return parent.find(simple_xpath)
    
    def _find_elements(self, parent, xpath: str):
        """Find multiple elements with namespace support"""
        try:
            return parent.findall(xpath, self.namespaces)
        except:
            # Fallback without namespaces
            simple_xpath = re.sub(r'\w+:', '', xpath)
            return parent.findall(simple_xpath)

def main():
    """Test the parser with sample files"""
    parser = InformaticaBDMParser()
    
    # Find XML files in current directory
    xml_files = list(Path('.').glob('*.xml'))
    
    if not xml_files:
        print("No XML files found in current directory")
        return
    
    for xml_file in xml_files[:3]:  # Test first 3 files
        print(f"\nParsing: {xml_file}")
        try:
            workflow = parser.parse_xml_file(str(xml_file))
            
            print(f"✅ Workflow: {workflow.name}")
            print(f"   Parameters: {len(workflow.parameters)}")
            print(f"   Mapping Tasks: {len(workflow.mapping_tasks)}")
            print(f"   Sequence Flows: {len(workflow.sequence_flows)}")
            
            for mapping_task in workflow.mapping_tasks:
                print(f"   Task '{mapping_task.name}': {len(mapping_task.transformations)} transformations")
                
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()