# Databricks notebook source
# MAGIC %md
# MAGIC # Informatica BDM Converter - Main Execution
# MAGIC 
# MAGIC This notebook executes the conversion of Informatica BDM workflows to Databricks notebooks.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

import sys
sys.path.append('/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/src')

from databricks_agent_system import AgentOrchestrator
from databricks_config import databricks_config
import time

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialize Agent System

# COMMAND ----------

# Initialize the agent orchestrator
orchestrator = AgentOrchestrator(max_workers=4)

print("🤖 Agent system initialized")
print(f"Available agents: {list(orchestrator.agents.keys())}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get XML Files

# COMMAND ----------

# Get list of XML files to process
xml_files = []

try:
    file_info = dbutils.fs.ls(databricks_config.XML_SOURCE_PATH)
    xml_files = [file.path for file in file_info if file.name.endswith('.xml')]
    
    print(f"Found {len(xml_files)} XML files:")
    for xml_file in xml_files[:10]:  # Show first 10
        print(f"  - {xml_file}")
    
    if len(xml_files) > 10:
        print(f"  ... and {len(xml_files) - 10} more files")
        
except Exception as e:
    print(f"Error accessing XML files: {e}")
    print("Please ensure XML files are uploaded to the xml_workflows directory")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Execute Conversion

# COMMAND ----------

if xml_files:
    print(f"🚀 Starting conversion of {len(xml_files)} workflows...")
    
    # Process workflows using agent system
    results = orchestrator.process_workflow_batch(xml_files)
    
    print(f"\n📊 Conversion Results:")
    print(f"✅ Successful: {results['successful_conversions']}")
    print(f"❌ Failed: {results['failed_conversions']}")
    print(f"⏱️ Total time: {results['processing_time']:.2f} seconds")
    
    # Display agent performance
    print(f"\n🤖 Agent Performance:")
    for agent_id, metrics in results['agent_metrics'].items():
        print(f"  {agent_id}: {metrics['success_rate']:.1%} success, {metrics['average_processing_time']:.2f}s avg")
    
else:
    print("❌ No XML files found. Please upload XML files to the xml_workflows directory.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## View Generated Notebooks

# COMMAND ----------

# List generated notebooks
try:
    notebook_files = dbutils.fs.ls(databricks_config.NOTEBOOKS_OUTPUT_PATH)
    
    print(f"Generated {len(notebook_files)} notebooks:")
    for notebook in notebook_files:
        if notebook.name.endswith('.py'):
            print(f"  📓 {notebook.name}")
            
except Exception as e:
    print(f"Error listing notebooks: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Conversion Metadata

# COMMAND ----------

if 'results' in locals() and results['workflow_results']:
    # Insert conversion results into tracking table
    from pyspark.sql.types import *
    from pyspark.sql.functions import *
    
    # Prepare data for insertion
    conversion_data = []
    for result in results['workflow_results']:
        conversion_data.append({
            'conversion_id': result['task_id'],
            'xml_file_path': result['xml_file'],
            'workflow_name': result['workflow_name'],
            'conversion_status': 'success' if result['success'] else 'failed',
            'start_time': current_timestamp(),
            'end_time': current_timestamp(),
            'processing_time_seconds': 0.0,  # Would need to track this
            'complexity_score': result.get('analysis', {}).get('complexity_score', 0),
            'success_rate': 1.0 if result['success'] else 0.0,
            'error_message': result.get('error', ''),
            'agent_id': 'orchestrator',
            'optimizations_applied': result.get('optimizations_applied', [])
        })
    
    # Create DataFrame and insert
    df_conversions = spark.createDataFrame(conversion_data)
    
    df_conversions.write \
        .format("delta") \
        .mode("append") \
        .saveAsTable("usdev_dataengineering.eds_us_lake_cdp.informatica_conversion_tracking")
    
    print("✅ Conversion metadata saved to tracking table")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Steps
# MAGIC 
# MAGIC 1. Review generated notebooks in the `generated_notebooks` directory
# MAGIC 2. Test individual notebooks with sample data
# MAGIC 3. Use the monitoring notebook to track conversion progress
# MAGIC 4. Schedule regular conversions using Databricks Jobs