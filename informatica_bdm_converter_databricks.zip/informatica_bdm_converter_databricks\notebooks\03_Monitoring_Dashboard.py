# Databricks notebook source
# MAGIC %md
# MAGIC # Informatica BDM Converter - Monitoring Dashboard
# MAGIC 
# MAGIC This notebook provides monitoring and analytics for the conversion process.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conversion Statistics

# COMMAND ----------

# Query conversion tracking table
conversion_stats = spark.sql("""
SELECT 
    conversion_status,
    COUNT(*) as count,
    AVG(complexity_score) as avg_complexity,
    AVG(processing_time_seconds) as avg_processing_time
FROM usdev_dataengineering.eds_us_lake_cdp.informatica_conversion_tracking
GROUP BY conversion_status
ORDER BY conversion_status
""")

display(conversion_stats)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Recent Conversions

# COMMAND ----------

recent_conversions = spark.sql("""
SELECT 
    workflow_name,
    conversion_status,
    complexity_score,
    processing_time_seconds,
    created_at,
    error_message
FROM usdev_dataengineering.eds_us_lake_cdp.informatica_conversion_tracking
ORDER BY created_at DESC
LIMIT 20
""")

display(recent_conversions)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Complexity Analysis

# COMMAND ----------

complexity_analysis = spark.sql("""
SELECT 
    CASE 
        WHEN complexity_score < 20 THEN 'Simple'
        WHEN complexity_score < 50 THEN 'Medium'
        WHEN complexity_score < 100 THEN 'Complex'
        ELSE 'Very Complex'
    END as complexity_category,
    COUNT(*) as workflow_count,
    AVG(CASE WHEN conversion_status = 'success' THEN 1.0 ELSE 0.0 END) as success_rate
FROM usdev_dataengineering.eds_us_lake_cdp.informatica_conversion_tracking
WHERE complexity_score > 0
GROUP BY 
    CASE 
        WHEN complexity_score < 20 THEN 'Simple'
        WHEN complexity_score < 50 THEN 'Medium'
        WHEN complexity_score < 100 THEN 'Complex'
        ELSE 'Very Complex'
    END
ORDER BY complexity_category
""")

display(complexity_analysis)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Performance Trends

# COMMAND ----------

# Daily conversion trends
daily_trends = spark.sql("""
SELECT 
    DATE(created_at) as conversion_date,
    COUNT(*) as total_conversions,
    SUM(CASE WHEN conversion_status = 'success' THEN 1 ELSE 0 END) as successful_conversions,
    AVG(complexity_score) as avg_complexity,
    AVG(processing_time_seconds) as avg_processing_time
FROM usdev_dataengineering.eds_us_lake_cdp.informatica_conversion_tracking
GROUP BY DATE(created_at)
ORDER BY conversion_date DESC
LIMIT 30
""")

display(daily_trends)