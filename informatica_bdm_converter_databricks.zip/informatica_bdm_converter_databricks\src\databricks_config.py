#!/usr/bin/env python3
"""
Databricks-specific configuration for Informatica BDM to Databricks conversion
Uses your volume path: usdev_dataengineering.eds_us_lake_cdp.volume_entcdp
"""

import os
from pathlib import Path
from typing import Dict, Any

class DatabricksConfig:
    """Configuration for Databricks environment"""
    
    def __init__(self):
        # Your Databricks volume paths
        self.VOLUME_BASE_PATH = "/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp"
        
        # Source and target paths within your volume
        self.XML_SOURCE_PATH = f"{self.VOLUME_BASE_PATH}/xml_workflows"
        self.NOTEBOOKS_OUTPUT_PATH = f"{self.VOLUME_BASE_PATH}/generated_notebooks"
        self.LOGS_PATH = f"{self.VOLUME_BASE_PATH}/conversion_logs"
        self.ANALYSIS_PATH = f"{self.VOLUME_BASE_PATH}/workflow_analysis"
        self.METADATA_PATH = f"{self.VOLUME_BASE_PATH}/metadata"
        
        # Delta Lake table paths (using your catalog and schema)
        self.CATALOG_NAME = "usdev_dataengineering"
        self.SCHEMA_NAME = "eds_us_lake_cdp"
        
        # Metadata tables for tracking conversion progress
        self.CONVERSION_TRACKING_TABLE = f"{self.CATALOG_NAME}.{self.SCHEMA_NAME}.informatica_conversion_tracking"
        self.WORKFLOW_METADATA_TABLE = f"{self.CATALOG_NAME}.{self.SCHEMA_NAME}.workflow_metadata"
        self.AGENT_PERFORMANCE_TABLE = f"{self.CATALOG_NAME}.{self.SCHEMA_NAME}.agent_performance_metrics"
        
        # Spark configuration optimized for your workload
        self.SPARK_CONFIG = {
            "spark.databricks.delta.optimizeWrite.enabled": "true",
            "spark.databricks.delta.autoCompact.enabled": "true",
            "spark.sql.adaptive.enabled": "true",
            "spark.sql.adaptive.coalescePartitions.enabled": "true",
            "spark.sql.adaptive.skewJoin.enabled": "true",
            "spark.databricks.io.cache.enabled": "true",
            "spark.sql.execution.arrow.pyspark.enabled": "true"
        }
    
    def get_xml_file_paths(self) -> list:
        """Get all XML files from your volume"""
        try:
            # Use dbutils to list files in Databricks volume
            xml_files = []
            file_info = dbutils.fs.ls(self.XML_SOURCE_PATH)
            
            for file in file_info:
                if file.name.endswith('.xml'):
                    xml_files.append(file.path)
            
            return xml_files
        except Exception as e:
            print(f"Error accessing XML files: {e}")
            return []
    
    def ensure_directories_exist(self):
        """Create necessary directories in your volume"""
        directories = [
            self.NOTEBOOKS_OUTPUT_PATH,
            self.LOGS_PATH,
            self.ANALYSIS_PATH,
            self.METADATA_PATH
        ]
        
        for directory in directories:
            try:
                dbutils.fs.mkdirs(directory)
                print(f"✅ Created directory: {directory}")
            except Exception as e:
                print(f"Directory may already exist: {directory}")
    
    def create_metadata_tables(self):
        """Create Delta tables for tracking conversion progress"""
        
        # Conversion tracking table
        conversion_tracking_ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.CONVERSION_TRACKING_TABLE} (
            conversion_id STRING,
            xml_file_path STRING,
            workflow_name STRING,
            conversion_status STRING,
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            processing_time_seconds DOUBLE,
            complexity_score INT,
            success_rate DOUBLE,
            error_message STRING,
            agent_id STRING,
            optimizations_applied ARRAY<STRING>,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
        ) USING DELTA
        PARTITIONED BY (DATE(created_at))
        """
        
        # Workflow metadata table
        workflow_metadata_ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.WORKFLOW_METADATA_TABLE} (
            workflow_id STRING,
            workflow_name STRING,
            xml_file_path STRING,
            notebook_path STRING,
            parameter_count INT,
            transformation_count INT,
            source_count INT,
            target_count INT,
            complexity_category STRING,
            estimated_runtime_minutes DOUBLE,
            dependencies ARRAY<STRING>,
            business_domain STRING,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
        ) USING DELTA
        """
        
        # Agent performance table
        agent_performance_ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.AGENT_PERFORMANCE_TABLE} (
            agent_id STRING,
            metric_name STRING,
            metric_value DOUBLE,
            measurement_time TIMESTAMP,
            additional_info MAP<STRING, STRING>,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
        ) USING DELTA
        PARTITIONED BY (DATE(created_at), agent_id)
        """
        
        # Execute DDL statements
        try:
            spark.sql(conversion_tracking_ddl)
            spark.sql(workflow_metadata_ddl)
            spark.sql(agent_performance_ddl)
            print("✅ Metadata tables created successfully")
        except Exception as e:
            print(f"Error creating metadata tables: {e}")
    
    def get_databricks_job_config(self, notebook_path: str, workflow_name: str) -> Dict[str, Any]:
        """Generate Databricks job configuration for converted workflow"""
        return {
            "name": f"Informatica_Migration_{workflow_name}",
            "new_cluster": {
                "cluster_name": f"migration-{workflow_name}-cluster",
                "spark_version": "13.3.x-scala2.12",
                "node_type_id": "i3.xlarge",
                "driver_node_type_id": "i3.xlarge",
                "num_workers": 2,
                "autoscale": {
                    "min_workers": 1,
                    "max_workers": 4
                },
                "spark_conf": self.SPARK_CONFIG,
                "custom_tags": {
                    "project": "informatica-migration",
                    "workflow": workflow_name,
                    "environment": "production"
                }
            },
            "notebook_task": {
                "notebook_path": notebook_path,
                "base_parameters": {
                    "catalog_name": self.CATALOG_NAME,
                    "schema_name": self.SCHEMA_NAME,
                    "volume_path": self.VOLUME_BASE_PATH,
                    "environment": "production"
                }
            },
            "timeout_seconds": 3600,
            "max_retries": 2,
            "email_notifications": {
                "on_failure": ["data-engineering@company.com"],
                "on_success": ["data-engineering@company.com"]
            },
            "webhook_notifications": {
                "on_failure": [
                    {
                        "id": "failure-webhook"
                    }
                ]
            }
        }

# Global configuration instance
databricks_config = DatabricksConfig()