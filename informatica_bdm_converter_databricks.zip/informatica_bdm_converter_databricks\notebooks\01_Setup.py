# Databricks notebook source
# MAGIC %md
# MAGIC # Informatica BDM Converter - Setup
# MAGIC 
# MAGIC This notebook sets up the Informatica BDM to Databricks converter in your workspace.
# MAGIC 
# MAGIC ## Prerequisites
# MAGIC - Databricks Runtime 13.3 LTS or higher
# MAGIC - Access to Unity Catalog
# MAGIC - Volume permissions for file storage

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Install Required Libraries

# COMMAND ----------

# Install required Python packages
%pip install lxml pathlib2

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Upload Source Files
# MAGIC 
# MAGIC Upload the source files from the `src/` directory to your Databricks workspace or volume.

# COMMAND ----------

# Verify volume access
volume_path = "/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp"

try:
    dbutils.fs.ls(volume_path)
    print(f"✅ Volume access confirmed: {volume_path}")
except Exception as e:
    print(f"❌ Volume access failed: {e}")
    print("Please ensure you have access to the specified volume")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Create Directory Structure

# COMMAND ----------

# Create necessary directories
directories = [
    f"{volume_path}/xml_workflows",
    f"{volume_path}/generated_notebooks", 
    f"{volume_path}/conversion_logs",
    f"{volume_path}/workflow_analysis",
    f"{volume_path}/metadata"
]

for directory in directories:
    try:
        dbutils.fs.mkdirs(directory)
        print(f"✅ Created: {directory}")
    except Exception as e:
        print(f"Directory may already exist: {directory}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Create Metadata Tables

# COMMAND ----------

# Create conversion tracking table
spark.sql("""
CREATE TABLE IF NOT EXISTS usdev_dataengineering.eds_us_lake_cdp.informatica_conversion_tracking (
    conversion_id STRING,
    xml_file_path STRING,
    workflow_name STRING,
    conversion_status STRING,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    processing_time_seconds DOUBLE,
    complexity_score INT,
    success_rate DOUBLE,
    error_message STRING,
    agent_id STRING,
    optimizations_applied ARRAY<STRING>,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
) USING DELTA
PARTITIONED BY (DATE(created_at))
""")

print("✅ Conversion tracking table created")

# COMMAND ----------

# Create workflow metadata table
spark.sql("""
CREATE TABLE IF NOT EXISTS usdev_dataengineering.eds_us_lake_cdp.workflow_metadata (
    workflow_id STRING,
    workflow_name STRING,
    xml_file_path STRING,
    notebook_path STRING,
    parameter_count INT,
    transformation_count INT,
    source_count INT,
    target_count INT,
    complexity_category STRING,
    estimated_runtime_minutes DOUBLE,
    dependencies ARRAY<STRING>,
    business_domain STRING,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
) USING DELTA
""")

print("✅ Workflow metadata table created")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Test Installation

# COMMAND ----------

# Test the parser
import sys
sys.path.append('/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/src')

try:
    from informatica_bdm_parser import InformaticaBDMParser
    from databricks_generator import DatabricksNotebookGenerator
    from workflow_analyzer import WorkflowAnalyzer
    
    print("✅ All modules imported successfully")
    print("🎉 Setup completed successfully!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Please ensure all source files are uploaded to the src directory")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Steps
# MAGIC 
# MAGIC 1. Upload your XML workflow files to `/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/xml_workflows/`
# MAGIC 2. Run the main execution notebook to start conversion
# MAGIC 3. Monitor progress using the monitoring notebook