#!/usr/bin/env python3
"""
Databricks Notebook Generator
Converts parsed Informatica BDM workflows to Databricks notebooks
"""

from informatica_bdm_parser import WorkflowDefinition, MappingTask, Transformation
from typing import Dict, List, Any
import re
from pathlib import Path

class DatabricksNotebookGenerator:
    """Generates Databricks notebooks from parsed Informatica workflows"""
    
    def __init__(self):
        self.transformation_mappers = {
            'expression': self._generate_expression_transformation,
            'joiner': self._generate_joiner_transformation,
            'lookup': self._generate_lookup_transformation,
            'filter': self._generate_filter_transformation,
            'router': self._generate_router_transformation,
            'sorter': self._generate_sorter_transformation,
            'source': self._generate_source_transformation,
            'target': self._generate_target_transformation
        }
    
    def generate_notebook(self, workflow: WorkflowDefinition) -> str:
        """Generate a complete Databricks notebook from workflow definition"""
        
        notebook_code = self._generate_header(workflow)
        notebook_code += self._generate_imports()
        notebook_code += self._generate_parameters(workflow.parameters)
        notebook_code += self._generate_spark_session()
        
        # Generate code for each mapping task
        for mapping_task in workflow.mapping_tasks:
            notebook_code += self._generate_mapping_task(mapping_task)
        
        notebook_code += self._generate_footer()
        
        return notebook_code
    
    def _generate_header(self, workflow: WorkflowDefinition) -> str:
        """Generate notebook header with metadata"""
        return f'''# Databricks notebook source
# MAGIC %md
# MAGIC # {workflow.name}
# MAGIC 
# MAGIC **Converted from Informatica BDM Workflow**
# MAGIC 
# MAGIC - Original Workflow ID: `{workflow.id}`
# MAGIC - Generated on: {self._get_current_timestamp()}
# MAGIC - Conversion Tool: Informatica BDM to Databricks Converter
# MAGIC 
# MAGIC ## Workflow Overview
# MAGIC This notebook contains the converted logic from the original Informatica BDM workflow.
# MAGIC All transformations have been converted to equivalent PySpark operations.

# COMMAND ----------

'''
    
    def _generate_imports(self) -> str:
        """Generate necessary imports"""
        return '''# MAGIC %md
# MAGIC ## Imports and Setup

# COMMAND ----------

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import DeltaTable
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# COMMAND ----------

'''
    
    def _generate_parameters(self, parameters: List) -> str:
        """Generate parameter definitions"""
        if not parameters:
            return ""
        
        code = '''# MAGIC %md
# MAGIC ## Workflow Parameters

# COMMAND ----------

# Workflow Parameters (converted from Informatica parameters)
'''
        
        for param in parameters:
            # Clean parameter name for Python variable
            clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', param.name).upper()
            
            # Handle different parameter types
            if param.default_value.startswith('s3://') or param.default_value.startswith('arn:'):
                code += f'{clean_name} = "{param.default_value}"\n'
            elif param.default_value.isdigit():
                code += f'{clean_name} = {param.default_value}\n'
            elif param.default_value.lower() in ['true', 'false']:
                code += f'{clean_name} = {param.default_value.title()}\n'
            else:
                code += f'{clean_name} = "{param.default_value}"\n'
        
        code += '\n# COMMAND ----------\n\n'
        return code
    
    def _generate_spark_session(self) -> str:
        """Generate Spark session configuration"""
        return '''# MAGIC %md
# MAGIC ## Spark Session Configuration

# COMMAND ----------

# Spark session is automatically available in Databricks as 'spark'
# Configure additional Spark settings if needed
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")

print(f"Spark Version: {spark.version}")
print(f"Available cores: {spark.sparkContext.defaultParallelism}")

# COMMAND ----------

'''
    
    def _generate_mapping_task(self, mapping_task: MappingTask) -> str:
        """Generate code for a complete mapping task"""
        code = f'''# MAGIC %md
# MAGIC ## Mapping Task: {mapping_task.name}

# COMMAND ----------

logger.info("Starting mapping task: {mapping_task.name}")

'''
        
        # Generate source transformations
        source_dfs = {}
        for source in mapping_task.sources:
            df_name, source_code = self._generate_source_transformation(source)
            code += source_code
            source_dfs[source.name] = df_name
        
        # Generate intermediate transformations
        current_df = None
        for transformation in mapping_task.transformations:
            if transformation.type in self.transformation_mappers:
                trans_code = self.transformation_mappers[transformation.type](transformation, current_df)
                code += trans_code
                current_df = f"df_{transformation.name.lower().replace(' ', '_')}"
        
        # Generate target transformations
        for target in mapping_task.targets:
            target_code = self._generate_target_transformation(target, current_df)
            code += target_code
        
        code += f'''
logger.info("Completed mapping task: {mapping_task.name}")

# COMMAND ----------

'''
        return code
    
    def _generate_source_transformation(self, source: Transformation) -> tuple:
        """Generate source data reading code"""
        df_name = f"df_{source.name.lower().replace(' ', '_')}"
        
        code = f'''# Source: {source.name}
# TODO: Configure actual source path and format
{df_name} = spark.read \\
    .format("delta") \\
    .option("path", "/path/to/source/{source.name}") \\
    .load()

print(f"Source {source.name} - Record count: {{{df_name}.count()}}")
{df_name}.printSchema()

'''
        return df_name, code
    
    def _generate_expression_transformation(self, transformation: Transformation, input_df: str = None) -> str:
        """Generate expression transformation code"""
        df_name = f"df_{transformation.name.lower().replace(' ', '_')}"
        input_df = input_df or "df_input"
        
        code = f'''# Expression Transformation: {transformation.name}
{df_name} = {input_df}'''
        
        if transformation.expressions:
            code += ' \\\n'
            expressions = []
            for field_name, expression in transformation.expressions.items():
                # Convert Informatica expression to Spark SQL
                spark_expr = self._convert_informatica_expression(expression)
                expressions.append(f'    .withColumn("{field_name}", {spark_expr})')
            
            code += ' \\\n'.join(expressions)
        
        code += f'''

print(f"Expression {transformation.name} - Record count: {{{df_name}.count()}}")

'''
        return code
    
    def _generate_joiner_transformation(self, transformation: Transformation, input_df: str = None) -> str:
        """Generate joiner transformation code"""
        df_name = f"df_{transformation.name.lower().replace(' ', '_')}"
        
        join_type = transformation.properties.get('join_type', 'INNER').lower()
        if join_type == 'normal':
            join_type = 'inner'
        
        code = f'''# Joiner Transformation: {transformation.name}
# TODO: Configure actual join logic based on source dataframes
{df_name} = df_left.join(
    df_right,
    on=[col("left_key") == col("right_key")],  # TODO: Configure actual join conditions
    how="{join_type}"
)

print(f"Joiner {transformation.name} - Record count: {{{df_name}.count()}}")

'''
        return code
    
    def _generate_lookup_transformation(self, transformation: Transformation, input_df: str = None) -> str:
        """Generate lookup transformation code"""
        df_name = f"df_{transformation.name.lower().replace(' ', '_')}"
        input_df = input_df or "df_input"
        
        code = f'''# Lookup Transformation: {transformation.name}
# TODO: Configure actual lookup table and conditions
lookup_df = spark.read.format("delta").load("/path/to/lookup/table")

{df_name} = {input_df}.join(
    broadcast(lookup_df),  # Using broadcast for small lookup tables
    on=[col("lookup_key")],  # TODO: Configure actual lookup conditions
    how="left"  # Default to left join for lookups
)

print(f"Lookup {transformation.name} - Record count: {{{df_name}.count()}}")

'''
        return code
    
    def _generate_filter_transformation(self, transformation: Transformation, input_df: str = None) -> str:
        """Generate filter transformation code"""
        df_name = f"df_{transformation.name.lower().replace(' ', '_')}"
        input_df = input_df or "df_input"
        
        code = f'''# Filter Transformation: {transformation.name}
{df_name} = {input_df}.filter(
    # TODO: Configure actual filter conditions
    col("filter_column").isNotNull()
)

print(f"Filter {transformation.name} - Record count: {{{df_name}.count()}}")

'''
        return code
    
    def _generate_router_transformation(self, transformation: Transformation, input_df: str = None) -> str:
        """Generate router transformation code"""
        df_name = f"df_{transformation.name.lower().replace(' ', '_')}"
        input_df = input_df or "df_input"
        
        code = f'''# Router Transformation: {transformation.name}
# TODO: Configure actual routing conditions
{df_name}_group1 = {input_df}.filter(col("route_condition") == "value1")
{df_name}_group2 = {input_df}.filter(col("route_condition") == "value2")
{df_name}_default = {input_df}.filter(
    ~(col("route_condition").isin(["value1", "value2"]))
)

print(f"Router {transformation.name} - Group1: {{{df_name}_group1.count()}}")
print(f"Router {transformation.name} - Group2: {{{df_name}_group2.count()}}")
print(f"Router {transformation.name} - Default: {{{df_name}_default.count()}}")

'''
        return code
    
    def _generate_sorter_transformation(self, transformation: Transformation, input_df: str = None) -> str:
        """Generate sorter transformation code"""
        df_name = f"df_{transformation.name.lower().replace(' ', '_')}"
        input_df = input_df or "df_input"
        
        code = f'''# Sorter Transformation: {transformation.name}
{df_name} = {input_df}.orderBy(
    # TODO: Configure actual sort columns and order
    col("sort_column").asc()
)

print(f"Sorter {transformation.name} - Record count: {{{df_name}.count()}}")

'''
        return code
    
    def _generate_target_transformation(self, target: Transformation, input_df: str = None) -> str:
        """Generate target data writing code"""
        input_df = input_df or "df_final"
        
        code = f'''# Target: {target.name}
# TODO: Configure actual target path and write options
{input_df}.write \\
    .format("delta") \\
    .mode("overwrite") \\
    .option("path", "/path/to/target/{target.name}") \\
    .save()

print(f"Target {target.name} - Records written: {{{input_df}.count()}}")

'''
        return code
    
    def _convert_informatica_expression(self, informatica_expr: str) -> str:
        """Convert Informatica expression syntax to Spark SQL"""
        # Basic conversion patterns
        spark_expr = informatica_expr
        
        # Convert common Informatica functions to Spark equivalents
        conversions = {
            'ISNULL': 'isnull',
            'NVL': 'coalesce',
            'SUBSTR': 'substring',
            'LENGTH': 'length',
            'UPPER': 'upper',
            'LOWER': 'lower',
            'LTRIM': 'ltrim',
            'RTRIM': 'rtrim',
            'TRIM': 'trim',
            'TO_DATE': 'to_date',
            'TO_CHAR': 'date_format',
            'SYSDATE': 'current_timestamp()'
        }
        
        for infa_func, spark_func in conversions.items():
            spark_expr = re.sub(f'\\b{infa_func}\\b', spark_func, spark_expr, flags=re.IGNORECASE)
        
        # Wrap in col() function if it's a simple column reference
        if spark_expr.isalnum() or '_' in spark_expr:
            return f'col("{spark_expr}")'
        else:
            return f'expr("{spark_expr}")'
    
    def _generate_footer(self) -> str:
        """Generate notebook footer"""
        return '''# MAGIC %md
# MAGIC ## Workflow Completion
# MAGIC 
# MAGIC The workflow has been successfully executed. All transformations have been applied
# MAGIC and data has been written to the target locations.

# COMMAND ----------

logger.info("Workflow execution completed successfully")
print("✅ Workflow completed successfully!")

# COMMAND ----------

'''
    
    def _get_current_timestamp(self) -> str:
        """Get current timestamp for header"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def main():
    """Test the generator with parsed workflows"""
    from informatica_bdm_parser import InformaticaBDMParser
    
    parser = InformaticaBDMParser()
    generator = DatabricksNotebookGenerator()
    
    # Test files
    test_files = [
        "wf_com_de_apac_hubtomart_ref_vn_terr_alignment.xml",
        "wf_com_de_apac_laketohub_txn_sales_my.xml"
    ]
    
    for xml_file in test_files:
        if Path(xml_file).exists():
            print(f"Processing: {xml_file}")
            
            try:
                # Parse the workflow
                workflow = parser.parse_xml_file(xml_file)
                
                # Generate Databricks notebook
                notebook_code = generator.generate_notebook(workflow)
                
                # Save to file
                output_file = f"{workflow.name}_databricks.py"
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(notebook_code)
                
                print(f"✅ Generated: {output_file}")
                
            except Exception as e:
                print(f"❌ Error processing {xml_file}: {e}")

if __name__ == "__main__":
    main()