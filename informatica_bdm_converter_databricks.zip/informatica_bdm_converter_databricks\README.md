# Informatica BDM to Databricks Converter

A comprehensive solution for converting Informatica Big Data Management (BDM) workflows to Databricks notebooks using an intelligent multi-agent system.

## 🚀 Quick Start

1. **Extract the package** to your local machine
2. **Upload to Databricks** following the deployment guide
3. **Run setup notebook** to initialize the environment
4. **Upload XML files** and start conversion

## 📁 Package Structure

```
informatica_bdm_converter_databricks/
├── src/                          # Core source code
│   ├── informatica_bdm_parser.py    # XML workflow parser
│   ├── databricks_generator.py      # Notebook generator
│   ├── workflow_analyzer.py         # Workflow analysis
│   ├── databricks_config.py         # Configuration
│   └── databricks_agent_system.py   # Multi-agent system
├── notebooks/                    # Databricks notebooks
│   ├── 01_Setup.py                  # Environment setup
│   ├── 02_Main_Execution.py         # Main conversion
│   └── 03_Monitoring_Dashboard.py   # Monitoring
├── config/                       # Configuration files
├── docs/                         # Documentation
├── examples/                     # Sample files
└── scripts/                      # Utility scripts
```

## 🎯 Features

### Multi-Agent System
- **Parser Agent**: Intelligent XML parsing
- **Generator Agent**: Databricks code generation
- **Analyzer Agent**: Workflow complexity analysis
- **Optimizer Agent**: Performance optimization
- **Validator Agent**: Code validation

### Supported Transformations
- Expression transformations → `withColumn()` operations
- Joiner transformations → DataFrame `join()` operations
- Lookup transformations → Broadcast joins
- Filter transformations → DataFrame `filter()` operations
- Router transformations → Conditional filtering
- Sorter transformations → `orderBy()` operations

## 📋 Prerequisites

### Databricks Environment
- Databricks Runtime 13.3 LTS or higher
- Unity Catalog enabled
- Volume access permissions

### Required Permissions
- Create and manage clusters
- Create and run notebooks
- Read/write access to Unity Catalog volumes
- Create tables in specified catalog/schema

## 🛠️ Installation Steps

### Step 1: Upload Files
1. Extract this package
2. Upload `src/` files to your Databricks workspace volume:
   `/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/src/`

### Step 2: Import Notebooks
1. Import notebooks from `notebooks/` directory to your Databricks workspace
2. Attach notebooks to a cluster with Databricks Runtime 13.3 LTS+

### Step 3: Run Setup
1. Open and run `01_Setup.py` notebook
2. This will create directories and metadata tables

### Step 4: Upload XML Files
Upload your Informatica XML workflow files to:
`/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp/xml_workflows/`

### Step 5: Execute Conversion
Run `02_Main_Execution.py` to start the conversion process

### Step 6: Monitor Progress
Use `03_Monitoring_Dashboard.py` to monitor conversion progress and results

## 📊 Configuration

Update these paths in `databricks_config.py` if needed:
```python
VOLUME_BASE_PATH = "/Volumes/usdev_dataengineering/eds_us_lake_cdp/volume_entcdp"
CATALOG_NAME = "usdev_dataengineering"
SCHEMA_NAME = "eds_us_lake_cdp"
```

## 📈 Performance Guidelines

### Cluster Sizing
- **Small workload** (< 100 workflows): 2-4 workers
- **Medium workload** (100-500 workflows): 4-8 workers
- **Large workload** (> 500 workflows): 8-16 workers

## 🔍 Troubleshooting

### Common Issues

#### Volume Access Denied
**Solution**: Ensure proper volume permissions for your user/service principal

#### Module Import Errors
**Solution**: Verify all source files are uploaded to the correct volume path

#### XML Parsing Errors
**Solution**: Validate XML file format and ensure they're valid Informatica BDM exports

## 📚 Next Steps After Deployment

1. **Test with Sample Data**: Use a few XML files first to validate the conversion
2. **Review Generated Notebooks**: Check the converted code for accuracy
3. **Performance Tuning**: Adjust cluster size based on your workload
4. **Schedule Jobs**: Set up Databricks Jobs for regular conversions
5. **Monitor Progress**: Use the monitoring dashboard to track success rates

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review Databricks documentation
3. Contact your data engineering team

---

**Package Version:** 1.0.0
**Compatible with:** Databricks Runtime 13.3 LTS+