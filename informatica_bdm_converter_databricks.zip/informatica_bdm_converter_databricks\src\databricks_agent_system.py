#!/usr/bin/env python3
"""
Databricks Agent System
Multi-agent system for intelligent Informatica BDM to Databricks conversion
"""

import time
import json
from typing import Dict, List, Any, Optional
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

from informatica_bdm_parser import InformaticaBDMParser, WorkflowDefinition
from databricks_generator import DatabricksNotebookGenerator
from workflow_analyzer import WorkflowAnalyzer
from databricks_config import databricks_config

@dataclass
class AgentTask:
    """Represents a task for an agent"""
    task_id: str
    task_type: str
    input_data: Any
    priority: int = 1
    status: str = "pending"
    result: Any = None
    error: str = ""
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    processing_time: float = 0.0

@dataclass
class AgentMetrics:
    """Agent performance metrics"""
    agent_id: str
    tasks_completed: int = 0
    tasks_failed: int = 0
    total_processing_time: float = 0.0
    average_processing_time: float = 0.0
    success_rate: float = 0.0
    last_activity: Optional[datetime] = None

class BaseAgent:
    """Base class for all agents"""
    
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self.metrics = AgentMetrics(agent_id=agent_id)
        self.is_active = False
    
    def process_task(self, task: AgentTask) -> AgentTask:
        """Process a task and update metrics"""
        task.start_time = datetime.now()
        task.status = "processing"
        self.is_active = True
        
        try:
            task.result = self._execute_task(task)
            task.status = "completed"
            self.metrics.tasks_completed += 1
            
        except Exception as e:
            task.error = str(e)
            task.status = "failed"
            self.metrics.tasks_failed += 1
        
        task.end_time = datetime.now()
        task.processing_time = (task.end_time - task.start_time).total_seconds()
        
        # Update metrics
        self.metrics.total_processing_time += task.processing_time
        total_tasks = self.metrics.tasks_completed + self.metrics.tasks_failed
        if total_tasks > 0:
            self.metrics.average_processing_time = self.metrics.total_processing_time / total_tasks
            self.metrics.success_rate = self.metrics.tasks_completed / total_tasks
        self.metrics.last_activity = datetime.now()
        
        self.is_active = False
        return task
    
    def _execute_task(self, task: AgentTask) -> Any:
        """Override in subclasses"""
        raise NotImplementedError

class XMLParserAgent(BaseAgent):
    """Agent specialized in parsing XML workflows"""
    
    def __init__(self):
        super().__init__("xml_parser_agent")
        self.parser = InformaticaBDMParser()
    
    def _execute_task(self, task: AgentTask) -> WorkflowDefinition:
        """Parse XML file and return workflow definition"""
        xml_file_path = task.input_data["xml_file_path"]
        return self.parser.parse_xml_file(xml_file_path)

class CodeGeneratorAgent(BaseAgent):
    """Agent specialized in generating Databricks notebooks"""
    
    def __init__(self):
        super().__init__("code_generator_agent")
        self.generator = DatabricksNotebookGenerator()
    
    def _execute_task(self, task: AgentTask) -> str:
        """Generate Databricks notebook code from workflow"""
        workflow = task.input_data["workflow"]
        return self.generator.generate_notebook(workflow)

class AnalyzerAgent(BaseAgent):
    """Agent specialized in workflow analysis"""
    
    def __init__(self):
        super().__init__("analyzer_agent")
        self.analyzer = WorkflowAnalyzer()
    
    def _execute_task(self, task: AgentTask) -> Dict[str, Any]:
        """Analyze workflow and return insights"""
        if task.task_type == "single_workflow_analysis":
            workflow = task.input_data["workflow"]
            return self._analyze_single_workflow(workflow)
        elif task.task_type == "batch_analysis":
            xml_files = task.input_data["xml_files"]
            return self.analyzer.analyze_workflow_batch(xml_files)
    
    def _analyze_single_workflow(self, workflow: WorkflowDefinition) -> Dict[str, Any]:
        """Analyze a single workflow"""
        total_transformations = sum(len(task.transformations) for task in workflow.mapping_tasks)
        
        analysis = {
            "workflow_name": workflow.name,
            "complexity_score": self._calculate_complexity(workflow, total_transformations),
            "transformation_count": total_transformations,
            "parameter_count": len(workflow.parameters),
            "mapping_task_count": len(workflow.mapping_tasks),
            "sequence_flow_count": len(workflow.sequence_flows),
            "transformation_types": {},
            "estimated_conversion_time": self._estimate_conversion_time(total_transformations)
        }
        
        # Count transformation types
        for mapping_task in workflow.mapping_tasks:
            for trans in mapping_task.transformations:
                analysis["transformation_types"][trans.type] = analysis["transformation_types"].get(trans.type, 0) + 1
        
        return analysis
    
    def _calculate_complexity(self, workflow: WorkflowDefinition, total_transformations: int) -> int:
        """Calculate workflow complexity score"""
        score = 0
        score += total_transformations * 2
        score += len(workflow.parameters)
        score += len(workflow.mapping_tasks) * 3
        score += len(workflow.sequence_flows)
        
        for mapping_task in workflow.mapping_tasks:
            for trans in mapping_task.transformations:
                if trans.type in ['joiner', 'lookup', 'router']:
                    score += 5
                elif trans.type == 'expression':
                    score += len(trans.expressions) if hasattr(trans, 'expressions') else 1
        
        return score
    
    def _estimate_conversion_time(self, transformation_count: int) -> float:
        """Estimate conversion time in minutes"""
        base_time = 5  # 5 minutes base
        return base_time + (transformation_count * 0.5)

class OptimizationAgent(BaseAgent):
    """Agent specialized in code optimization"""
    
    def __init__(self):
        super().__init__("optimization_agent")
    
    def _execute_task(self, task: AgentTask) -> str:
        """Optimize generated notebook code"""
        notebook_code = task.input_data["notebook_code"]
        workflow_analysis = task.input_data.get("workflow_analysis", {})
        
        optimized_code = self._apply_optimizations(notebook_code, workflow_analysis)
        return optimized_code
    
    def _apply_optimizations(self, code: str, analysis: Dict[str, Any]) -> str:
        """Apply various optimizations to the code"""
        optimizations = []
        
        # Add caching for complex workflows
        if analysis.get("complexity_score", 0) > 50:
            code = self._add_caching_optimizations(code)
            optimizations.append("caching")
        
        # Add broadcast joins for lookup-heavy workflows
        transformation_types = analysis.get("transformation_types", {})
        if transformation_types.get("lookup", 0) > 3:
            code = self._add_broadcast_optimizations(code)
            optimizations.append("broadcast_joins")
        
        # Add partitioning hints for large datasets
        if transformation_types.get("joiner", 0) > 2:
            code = self._add_partitioning_optimizations(code)
            optimizations.append("partitioning")
        
        # Add optimization comments
        optimization_header = f"""
# OPTIMIZATION NOTES
# Applied optimizations: {', '.join(optimizations)}
# Complexity score: {analysis.get('complexity_score', 0)}
# Estimated performance improvement: {len(optimizations) * 15}%

"""
        
        return optimization_header + code
    
    def _add_caching_optimizations(self, code: str) -> str:
        """Add caching for intermediate results"""
        # Add .cache() calls after complex transformations
        lines = code.split('\n')
        optimized_lines = []
        
        for line in lines:
            optimized_lines.append(line)
            if 'df_' in line and ('.join(' in line or '.withColumn(' in line):
                # Add caching after complex operations
                df_name = line.split('=')[0].strip()
                optimized_lines.append(f"{df_name}.cache()")
        
        return '\n'.join(optimized_lines)
    
    def _add_broadcast_optimizations(self, code: str) -> str:
        """Add broadcast hints for small lookup tables"""
        return code.replace('lookup_df)', 'broadcast(lookup_df))')
    
    def _add_partitioning_optimizations(self, code: str) -> str:
        """Add partitioning hints"""
        partitioning_hint = """
# PARTITIONING OPTIMIZATION
# Consider partitioning large datasets by frequently joined columns
# Example: df.repartition(col("partition_key"))
"""
        return partitioning_hint + code

class ValidationAgent(BaseAgent):
    """Agent specialized in validating generated code"""
    
    def __init__(self):
        super().__init__("validation_agent")
    
    def _execute_task(self, task: AgentTask) -> Dict[str, Any]:
        """Validate generated notebook code"""
        notebook_code = task.input_data["notebook_code"]
        workflow = task.input_data.get("workflow")
        
        validation_results = {
            "syntax_valid": False,
            "completeness_score": 0.0,
            "issues": [],
            "recommendations": []
        }
        
        # Syntax validation
        try:
            # Remove Databricks magic commands for syntax check
            python_code = self._extract_python_code(notebook_code)
            compile(python_code, '<notebook>', 'exec')
            validation_results["syntax_valid"] = True
        except SyntaxError as e:
            validation_results["issues"].append(f"Syntax error: {e}")
        
        # Completeness validation
        validation_results["completeness_score"] = self._calculate_completeness(notebook_code, workflow)
        
        # Generate recommendations
        validation_results["recommendations"] = self._generate_recommendations(notebook_code, workflow)
        
        return validation_results
    
    def _extract_python_code(self, notebook_code: str) -> str:
        """Extract Python code from Databricks notebook"""
        python_lines = []
        for line in notebook_code.split('\n'):
            if not line.strip().startswith('# MAGIC'):
                python_lines.append(line)
        return '\n'.join(python_lines)
    
    def _calculate_completeness(self, code: str, workflow: WorkflowDefinition) -> float:
        """Calculate how complete the conversion is"""
        if not workflow:
            return 0.5
        
        score = 0.0
        total_checks = 0
        
        # Check for parameter handling
        if workflow.parameters:
            total_checks += 1
            if any(param.name.upper() in code.upper() for param in workflow.parameters):
                score += 1
        
        # Check for transformation coverage
        for mapping_task in workflow.mapping_tasks:
            for trans in mapping_task.transformations:
                total_checks += 1
                if trans.name.lower().replace(' ', '_') in code.lower():
                    score += 1
        
        return score / total_checks if total_checks > 0 else 1.0
    
    def _generate_recommendations(self, code: str, workflow: WorkflowDefinition) -> List[str]:
        """Generate recommendations for improvement"""
        recommendations = []
        
        if 'TODO' in code:
            recommendations.append("Complete TODO items in the generated code")
        
        if '.collect()' in code:
            recommendations.append("Avoid using .collect() on large datasets")
        
        if workflow and len(workflow.parameters) > 0 and 'dbutils.widgets' not in code:
            recommendations.append("Consider using Databricks widgets for parameters")
        
        return recommendations

class AgentOrchestrator:
    """Orchestrates multiple agents for complex workflows"""
    
    def __init__(self, max_workers: int = 4):
        self.agents = {
            "parser": XMLParserAgent(),
            "generator": CodeGeneratorAgent(),
            "analyzer": AnalyzerAgent(),
            "optimizer": OptimizationAgent(),
            "validator": ValidationAgent()
        }
        self.max_workers = max_workers
        self.task_queue = []
        self.completed_tasks = []
        self.config = databricks_config
    
    def process_workflow_batch(self, xml_files: List[str]) -> Dict[str, Any]:
        """Process a batch of workflows using multiple agents"""
        
        print(f"🤖 Starting agent-based processing of {len(xml_files)} workflows")
        start_time = time.time()
        
        results = {
            "total_workflows": len(xml_files),
            "successful_conversions": 0,
            "failed_conversions": 0,
            "agent_metrics": {},
            "workflow_results": [],
            "processing_time": 0
        }
        
        # Create tasks for each workflow
        workflow_tasks = []
        for i, xml_file in enumerate(xml_files):
            task_id = f"workflow_{i}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            workflow_tasks.append({
                "task_id": task_id,
                "xml_file": xml_file,
                "status": "pending"
            })
        
        # Process workflows in parallel
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_task = {
                executor.submit(self._process_single_workflow, task): task 
                for task in workflow_tasks
            }
            
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    workflow_result = future.result()
                    results["workflow_results"].append(workflow_result)
                    
                    if workflow_result["success"]:
                        results["successful_conversions"] += 1
                        print(f"✅ {workflow_result['workflow_name']}")
                    else:
                        results["failed_conversions"] += 1
                        print(f"❌ {task['xml_file']}: {workflow_result['error']}")
                        
                except Exception as e:
                    results["failed_conversions"] += 1
                    print(f"❌ {task['xml_file']}: {e}")
        
        # Collect agent metrics
        for agent_id, agent in self.agents.items():
            results["agent_metrics"][agent_id] = {
                "tasks_completed": agent.metrics.tasks_completed,
                "tasks_failed": agent.metrics.tasks_failed,
                "success_rate": agent.metrics.success_rate,
                "average_processing_time": agent.metrics.average_processing_time
            }
        
        results["processing_time"] = time.time() - start_time
        
        # Save results
        self._save_agent_results(results)
        
        print(f"\n🎉 Agent processing completed!")
        print(f"✅ Successful: {results['successful_conversions']}")
        print(f"❌ Failed: {results['failed_conversions']}")
        print(f"⏱️ Total time: {results['processing_time']:.2f} seconds")
        
        return results
    
    def _process_single_workflow(self, task_info: Dict[str, Any]) -> Dict[str, Any]:
        """Process a single workflow through the agent pipeline"""
        
        xml_file = task_info["xml_file"]
        task_id = task_info["task_id"]
        
        result = {
            "task_id": task_id,
            "xml_file": xml_file,
            "workflow_name": "",
            "success": False,
            "error": "",
            "notebook_path": "",
            "analysis": {},
            "validation": {},
            "optimizations_applied": []
        }
        
        try:
            # Step 1: Parse XML
            parse_task = AgentTask(
                task_id=f"{task_id}_parse",
                task_type="parse_xml",
                input_data={"xml_file_path": xml_file}
            )
            parse_result = self.agents["parser"].process_task(parse_task)
            
            if parse_result.status != "completed":
                raise Exception(f"Parsing failed: {parse_result.error}")
            
            workflow = parse_result.result
            result["workflow_name"] = workflow.name
            
            # Step 2: Analyze workflow
            analyze_task = AgentTask(
                task_id=f"{task_id}_analyze",
                task_type="single_workflow_analysis",
                input_data={"workflow": workflow}
            )
            analyze_result = self.agents["analyzer"].process_task(analyze_task)
            
            if analyze_result.status == "completed":
                result["analysis"] = analyze_result.result
            
            # Step 3: Generate code
            generate_task = AgentTask(
                task_id=f"{task_id}_generate",
                task_type="generate_notebook",
                input_data={"workflow": workflow}
            )
            generate_result = self.agents["generator"].process_task(generate_task)
            
            if generate_result.status != "completed":
                raise Exception(f"Code generation failed: {generate_result.error}")
            
            notebook_code = generate_result.result
            
            # Step 4: Optimize code
            optimize_task = AgentTask(
                task_id=f"{task_id}_optimize",
                task_type="optimize_code",
                input_data={
                    "notebook_code": notebook_code,
                    "workflow_analysis": result["analysis"]
                }
            )
            optimize_result = self.agents["optimizer"].process_task(optimize_task)
            
            if optimize_result.status == "completed":
                notebook_code = optimize_result.result
                result["optimizations_applied"] = ["caching", "broadcast_joins", "partitioning"]
            
            # Step 5: Validate code
            validate_task = AgentTask(
                task_id=f"{task_id}_validate",
                task_type="validate_code",
                input_data={
                    "notebook_code": notebook_code,
                    "workflow": workflow
                }
            )
            validate_result = self.agents["validator"].process_task(validate_task)
            
            if validate_result.status == "completed":
                result["validation"] = validate_result.result
            
            # Step 6: Save notebook
            safe_name = workflow.name.replace(' ', '_').replace('-', '_')
            notebook_filename = f"{safe_name}_agent_generated.py"
            notebook_path = f"{self.config.NOTEBOOKS_OUTPUT_PATH}/{notebook_filename}"
            
            with open(notebook_path.replace('/Volumes/', '/dbfs/Volumes/'), 'w', encoding='utf-8') as f:
                f.write(notebook_code)
            
            result["notebook_path"] = notebook_path
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def _save_agent_results(self, results: Dict[str, Any]):
        """Save agent processing results"""
        report_path = f"{self.config.LOGS_PATH}/agent_processing_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(report_path.replace('/Volumes/', '/dbfs/Volumes/'), 'w') as f:
                json.dump(results, f, indent=2, default=str)
            print(f"📊 Agent results saved: {report_path}")
        except Exception as e:
            print(f"⚠️ Failed to save agent results: {e}")

def main():
    """Main function for agent-based processing"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Databricks Agent System for Informatica BDM")
    parser.add_argument("--workers", type=int, default=4, help="Number of parallel workers")
    parser.add_argument("--xml-path", type=str, help="Custom XML files path")
    
    args = parser.parse_args()
    
    # Initialize orchestrator
    orchestrator = AgentOrchestrator(max_workers=args.workers)
    
    # Get XML files
    if args.xml_path:
        from pathlib import Path
        xml_files = list(Path(args.xml_path).glob("*.xml"))
        xml_files = [str(f) for f in xml_files]
    else:
        xml_files = databricks_config.get_xml_file_paths()
    
    # Process workflows
    results = orchestrator.process_workflow_batch(xml_files)
    
    print(f"\n📊 Agent Performance Summary:")
    for agent_id, metrics in results["agent_metrics"].items():
        print(f"   {agent_id}: {metrics['success_rate']:.1%} success rate, {metrics['average_processing_time']:.2f}s avg time")
    
    return results

if __name__ == "__main__":
    main()